<?php
$name='XBZar-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 1025,
  'Descent' => -488,
  'CapHeight' => 680,
  'Flags' => 262148,
  'FontBBox' => '[-323 -714 1807 1223]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 629,
);
$up=-278;
$ut=29;
$ttffile='/home/tucontac/public_html/morenoaldana.com/pdf/ttfonts/XB Zar Bd.ttf';
$TTCfontID='0';
$originalsize=1389628;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='xbzarB';
$panose=' 0 0 2 0 8 3 9 0 0 2 0 3';
$haskerninfo=false;
$unAGlyphs=true;
?>