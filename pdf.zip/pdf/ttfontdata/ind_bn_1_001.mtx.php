<?php
$name='ind_bn_1_001';
$type='TTF';
$desc=array (
  'Ascent' => 1000,
  'Descent' => -660,
  'CapHeight' => 1000,
  'Flags' => 4,
  'FontBBox' => '[-690 -449 1340 1004]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-215;
$ut=39;
$ttffile='/home/tucontac/public_html/morenoaldana.com/pdf/ttfonts/ind_bn_1_001.ttf';
$TTCfontID='0';
$originalsize=235632;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ind_bn_1_001';
$panose=' 0 0 2 b 6 6 3 8 4 2 2 4';
$kerninfo=array (
);
$haskerninfo=true;
$unAGlyphs=false;
?>