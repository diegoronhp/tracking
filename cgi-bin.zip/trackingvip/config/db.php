<?php

/* define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'tucontac_track1');//Usuario de tu base de datos
define('DB_PASS', '$$tracking@1');//Contraseña del usuario de la base de datos
define('DB_NAME', 'tucontac_tracking'); //Nombre de la base de datos */


define('$hostname_track', 'localhost');//$hostname_track:  generalmente suele ser "127.0.0.1"
define('$username_track', 'tucontac_track1');//Usuario de tu base de datos
define('$password_track', 'tracking@1');//Contraseña del usuario de la base de datos
define('$database_track', 'tucontac_tracking');//Nombre de la base de datos


?>