<?php


$hostname_track = "localhost";
$database_track = "tucontac_tracking";
$username_track = "tucontac_track1";
$password_track = "tracking@1";
$track = mysql_pconnect($hostname_track, $username_track, $password_track) or trigger_error(mysql_error(),E_USER_ERROR);
header('Content-Type: text/html; charset=ISO-8859-1');
session_start();

$_GET['id_cliente'];
$_GET['id_grupo'];
$_GET['fecha'];
$cliente=$_GET['id_cliente'];
$grupo=$_GET['id_grupo'];
$fecha="'".$_GET['fecha']."'";
$q1 = $_SESSION['q1'];
$q2 = $_SESSION['q2'];
function nombremes($mes){
 setlocale(LC_TIME, 'spanish');  
 $nombre=strftime("%B",mktime(0, 0, 0, $mes, 1, 2000)); 
 return $nombre;
} 


mysql_select_db($database_track,$track);
$query_consultanom = "SELECT * FROM clientes WHERE id_cliente=$cliente";
$consultanom = mysql_query($query_consultanom, $track) or die(mysql_error());
$row_consultanom = mysql_fetch_assoc($consultanom);


$corte=$row_consultanom["dia_corte"];

mysql_select_db($database_track,$track);
$query_consultotal = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo order by fecha ASC";
$consultotal = mysql_query($query_consultotal, $track) or die(mysql_error());
$row_consultotal = mysql_fetch_assoc($consultotal);

mysql_select_db($database_track,$track);
$query_consulplacas = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo order by fecha ASC";
$consulplacas = mysql_query($query_consulplacas, $track) or die(mysql_error());
$row_consulplacas = mysql_fetch_assoc($consulplacas);


mysql_select_db($database_track,$track);
$query_consultotala = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";
$consultotala = mysql_query($query_consultotala, $track) or die(mysql_error());
$row_consultotala = mysql_fetch_assoc($consultotala);

mysql_select_db($database_track,$track);
$query_consulplacasa = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";
$consulplacasa = mysql_query($query_consulplacasa, $track) or die(mysql_error());
$row_consulplacasa = mysql_fetch_assoc($consulplacasa);


if ($row_consultanom["cobro"]=='Anticipado') {
	
mysql_select_db($database_track,$track);
$query_consultotalap = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1-1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";
$consultotalap = mysql_query($query_consultotalap, $track) or die(mysql_error());
$row_consultotalap = mysql_fetch_assoc($consultotalap);

mysql_select_db($database_track,$track);
// no toma dias julio 9 - $query_consulplacasap = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1-1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";
$dia=$row_consultanom["dia_corte"];	
$mespro = $q1-1;
$query_consulplacasap = "SELECT SUM(DATEDIFF(CONCAT($q2,'-',$mespro,'-',$dia), fecha)) AS losdias, id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1-1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";

$consulplacasap = mysql_query($query_consulplacasap, $track) or die(mysql_error());
$row_consulplacasap = mysql_fetch_assoc($consulplacasap);

}

if ($row_consultanom["cobro"]=='Vencido') {
$dia=$row_consultanom["dia_corte"];

$mespro = $q1;
$mespro2 = $q1+1;
mysql_select_db($database_track,$track);
$query_consultotalap = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC";
$consultotalap = mysql_query($query_consultotalap, $track) or die(mysql_error());
$row_consultotalap = mysql_fetch_assoc($consultotalap);

mysql_select_db($database_track,$track);
/* $query_consulplacasap = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC"; */
$query_consulplacasap = "SELECT SUM(DATEDIFF(CONCAT($q2,'-',$mespro2,'-',$dia), fecha)) AS losdias, id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$mespro2,'-',$dia) AND fecha > CONCAT($q2,'-',$q1,'-',$dia) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='ARRIENDO' order by fecha ASC"; 
$consulplacasap = mysql_query($query_consulplacasap, $track) or die(mysql_error());
$row_consulplacasap = mysql_fetch_assoc($consulplacasap);

}

	
mysql_select_db($database_track,$track);
$query_consultotalc = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consultotalc = mysql_query($query_consultotalc, $track) or die(mysql_error());
$row_consultotalc = mysql_fetch_assoc($consultotalc);

mysql_select_db($database_track,$track);
$query_consulplacasc = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$corte) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacasc = mysql_query($query_consulplacasc, $track) or die(mysql_error());
$row_consulplacasc = mysql_fetch_assoc($consulplacasc);


if ($row_consultanom["cobro"]=='Anticipado') {

mysql_select_db($database_track,$track);
$query_consultotalcp = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1-1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consultotalcp = mysql_query($query_consultotalcp, $track) or die(mysql_error());
$row_consultotalcp = mysql_fetch_assoc($consultotalcp);

$dia=$row_consultanom["dia_corte"];	
$mespro = $q1-1;
mysql_select_db($database_track,$track);
$query_consulplacascp = "SELECT SUM(DATEDIFF(CONCAT($q2,'-',$mespro,'-',$dia), fecha)) AS losdias, id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$q1,'-',$dia) AND fecha > CONCAT($q2,'-',$mespro,'-',$dia) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacascp = mysql_query($query_consulplacascp, $track) or die(mysql_error());
$row_consulplacascp = mysql_fetch_assoc($consulplacascp);
	
$mespro = $q1-1;
mysql_select_db($database_track,$track);
$query_consulplacascp1 = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND MONTH(fecha) = ($q1-1) AND YEAR(fecha) = $q2 AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacascp1 = mysql_query($query_consulplacascp1, $track) or die(mysql_error());
$row_consulplacascp1 = mysql_fetch_assoc($consulplacascp1);

}


if ($row_consultanom["cobro"]=='Vencido') {

// julio 5 2018 no calcula dias de compra prorrateo $dia = $row_consultanom["dia_corte"]-1;
$dia = $row_consultanom["dia_corte"];
$mespro = $q1;
$mespro2 = $q1+1;
mysql_select_db($database_track,$track);
$query_consultotalcp = "SELECT COUNT(*) AS cantidad, id_cliente, SUM(valor_mensual) AS total, estado, placa, id_grupos, fecha, tipo_contrato FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$mespro2,'-',$dia) AND fecha > CONCAT($q2,'-',$q1,'-',$dia)AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consultotalcp = mysql_query($query_consultotalcp, $track) or die(mysql_error());
$row_consultotalcp = mysql_fetch_assoc($consultotalcp);

/* nuevo - agosto 6 2018 */
$a_date = $q2.'-'.$q1.'-'.$dia;
$fecha = new DateTime($a_date);
$fecha->modify('last day of this month');
$uldia = $fecha->format('d');

mysql_select_db($database_track,$track);
$query_consulplacascp = "SELECT SUM(DATEDIFF(CONCAT($q2,'-',$q1,'-',$uldia), fecha)) AS losdias, id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$mespro2,'-',$dia) AND fecha > CONCAT($q2,'-',$q1,'-',$dia) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacascp = mysql_query($query_consulplacascp, $track) or die(mysql_error());
$row_consulplacascp = mysql_fetch_assoc($consulplacascp);

/* no funcionan dias- agosto 6 2018
mysql_select_db($database_track,$track);
$query_consulplacascp = "SELECT SUM(DATEDIFF(CONCAT($q2,'-',$q1,'-',$dia), fecha)) AS losdias, id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$mespro2,'-',$dia) AND fecha > CONCAT($q2,'-',$q1,'-',$dia) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacascp = mysql_query($query_consulplacascp, $track) or die(mysql_error());
$row_consulplacascp = mysql_fetch_assoc($consulplacascp);
fin agos 6 2018 */

	/* mostrar listado de placas */
mysql_select_db($database_track,$track);
$query_consulplacascp1 = "SELECT id_cliente, estado, id_grupos, fecha, placa FROM movequipos WHERE estado='a' AND fecha < CONCAT($q2,'-',$mespro2,'-',$dia) AND fecha > CONCAT($q2,'-',$q1,'-',$dia) AND id_cliente=$cliente AND id_grupos=$grupo AND tipo_contrato='COMPRA' order by fecha ASC";
$consulplacascp1 = mysql_query($query_consulplacascp1, $track) or die(mysql_error());
$row_consulplacascp1 = mysql_fetch_assoc($consulplacascp1);

}

/*
$iva=round($row_consultotal["total"]*19/119);
*/
			  if ($row_consultotala["total"] > 0) {
$subtotala=$row_consultotala["total"]-round($row_consultotala["total"]*19/119);
$valor_unia=$subtotala/$row_consultotala["cantidad"];
				} else {
				  $subtotala = 0;
				  $valor_unia = 0;
			  }

              if ($row_consultotalap["total"] > 0) {
// $valora=($row_consultotalap["total"]/30/$row_consultotalap["cantidad"])*(30-abs($row_consulplacasap["losdias"])); cambio 5 sep 2018, toma los dias restantes
$valora=($row_consultotalap["total"]/30/$row_consultotalap["cantidad"])*(abs($row_consulplacasap["losdias"])-1);
$subtotal2=$valora-round($valora*19/119);
$valor_uni2=$subtotalap/$row_consultotalap["cantidad"];
				} else {
				  $subtotal2 = 0;
				  $valor_uni2 = 0;
			  }

			  if ($row_consultotalc["total"] > 0) {
$subtotalc=$row_consultotalc["total"]-round($row_consultotalc["total"]*19/119);
$valor_unic=$subtotalc/$row_consultotalc["cantidad"];
} else {
				  $subtotalc = 0;
				  $valor_unic = 0;
			  }
if ($row_consultotalcp["total"] > 0) {
/* JULIO 5 2018 TOMA MAL CANTIDAD
$valorc=(($row_consultotalcp["total"]/$row_consultotalcp["cantidad"])/30)*((30*$row_consultotalcp["cantidad"])-abs($row_consulplacascp["losdias"])); */
/* JULIO 7 2018 TOMA MAL CANTIDAD
$valorc=(($row_consultotalcp["total"]/$row_consultotalcp["cantidad"])/30)*(abs($row_consulplacascp["losdias"])); */
/* AGOSTO 6 2018 TOMA MAL VALOR
$valorc=(($row_consultotalcp["total"]/$row_consultotalcp["cantidad"])/30)*((30*$row_consultotalcp["cantidad"])-abs($row_consulplacascp["losdias"]));
$subtotal1=$valorc-round($valorc*19/119);
$valor_uni1=$subtotal1/$row_consultotalcp["cantidad"]; */

$valorc=(($row_consultotalcp["total"]/$row_consultotalcp["cantidad"])/30)*abs($row_consulplacascp["losdias"]);
$subtotal1=$valorc-round($valorc*19/119);
$valor_uni1=$subtotal1/$row_consultotalcp["cantidad"];
} else {
				  $subtotal1 = 0;
				  $valor_uni1 = 0;
			  }

$subtotal=$subtotala+$subtotalc+$subtotal1+$subtotal2;
$iva=round($subtotal*0.19);
$retefuente=round($subtotal*0.04);
$reteica=round($subtotal*0.00966);
$total=$subtotal+$iva-$retefuente-$reteica;
$valortotal=$subtotal+$iva;

    $active_facturas="active";
	$active_productos="";
	$active_clientes="";
	$active_usuarios="";	
	$title="Facturacion";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//ES" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title><?php echo $title;?></title>

<script language="JavaScript" src="src/js/jquery-1.5.1.min.js"></script>
<script language="JavaScript" src="js/jquery-ui-1.8.13.custom.min.js"></script>
<link type="text/css" href="css/ui-lightness/jquery-ui-1.8.13.custom.css" rel="stylesheet" />
<link rel="stylesheet" href="css/custom.css">
<link rel="stylesheet" href="css/login.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<script src="config/ckeditor/ckeditor.js"></script>
	<script src="config/ckeditor/samples/js/sample.js"></script>
	<link rel="stylesheet" href="config/ckeditor/samples/css/samples.css">
	<link rel="stylesheet" href="config/ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">


</head>
<body>

	
<?php include("config/menu.php");?>


<div class="container">

	<div class="panel panel-info">
		<div class="panel-heading">
		   <div class="btn-group pull-right">
        		        
	        	<!-- <a href="#popnw" class="btn btn-default" title='Nuevo cliente' onclick="obtener_datos('<?php echo $id_cliente;?>');" ><i class="glyphicon glyphicon-user"> Nuevo Cliente </i></a>	        
				<!-- <button type='button' class="btn btn-info" data-toggle="modal" data-target="#popnw"><span class="glyphicon glyphicon-plus" ></span> Nuevo Cliente</button> -->
			</div>
			<h4><i class='glyphicon glyphicon-list-alt'></i> Factura <?php echo $row_consultanom["nombre"]; ?> - Periodo <?php echo nombremes($q1);?> <?php echo $q2;?></h4>
		</div>
		<div class="panel-body">
		
		
		<div class="popup-contenedor">
		  <div class="modal-body">
			<form class="form-horizontal" method="post" id="new_factura" name="new_factura" action="Connections/new_factura.php">
			<input type="hidden" value="<?php echo $row_consultanom["id_cliente"]; ?>" id="id_cliente" name="id_cliente">
			<input type="hidden" value="<?php echo $grupo; ?>" id="id_grupo" name="id_grupo">
			<input type="hidden" value="mensualidad" id="motivo" name="motivo">
			<input type="hidden" value="a" id="estado" name="estado">
			<input type="hidden" value="<?php echo $valor_unic;?>" id="valor_unic" name="valor_unic">
			<input type="hidden" value="<?php echo $valor_unia;?>" id="valor_unia" name="valor_unia">
			<input type="hidden" value="<?php echo $valor_uni1;?>" id="valor_uni1" name="valor_uni1">
			<input type="hidden" value="<?php echo $valor_uni2;?>" id="valor_uni2" name="valor_uni2">
			<input type="hidden" value="<?php echo $iva;?>" id="iva" name="iva">
			<input type="hidden" value="<?php echo $retefuente;?>" id="retefuente" name="retefuente">
			<input type="hidden" value="<?php echo $reteica;?>" id="reteica" name="reteica">
			<input type="hidden" value="<?php echo $valortotal;?>" id="valor_total" name="valor_total">
			<input type="hidden" value="<?php echo $total;?>" id="total" name="total">
			<input type="hidden" value="<?php echo $subtotal;?>" id="subtotal" name="subtotal">
			<input type="hidden" value="<?php echo $subtotala;?>" id="subtotala" name="subtotala">
			<input type="hidden" value="<?php echo $subtotalc;?>" id="subtotalc" name="subtotalc">
			<input type="hidden" value="<?php echo $subtotal1;?>" id="subtotal1" name="subtotal1">
			<input type="hidden" value="<?php echo $subtotal2;?>" id="subtotal2" name="subtotal2">
			<input type="hidden" value="<?php echo $q2.$q1;?>" id="periodo" name="periodo">
			
		  <div class="form-group row">
          <div class="col-md-3">
          <label for="ex1"> Fecha Factura</label> 
           <input type="date" name="fecha_fact" id="fecha_fact" required>
          </div>
		  <div class="col-md-3">
          <label for="ex1"> Fecha Vencimiento</label> 
           <input type="date" name="fecha_venc" id="fecha_venc" required>
          </div>
          <div class="col-md-2">
          <label for="ex1"> Factura No.</label>
          <input class="form-control" id="factura" name="factura" type="text" required>
          </div>
          <div class="col-md-4">          
          <div class="radio">
          <label><input type="radio" name="banco" id="banco" checked value="avvillas">Av Villas</label>
          </div>
          <div class="radio">
          <label><input type="radio" name="banco" id="banco" value="bogota">Bogota</label>
          </div>
          </div>
			  </div>
		  <div class="form-group row">
          <div class="col-md-7">
          <label for="ex1"> Nombre</label>
          <input class="form-control" id="ss5" value="<?php echo $row_consultanom["nombre"]; ?>" readonly type="text">
           </div> 
		  <div class="col-md-2">
          <label for="ex1"> Nit</label>
          <input class="form-control" id="ss4" value="<?php echo $row_consultanom["nit"]; ?>" readonly type="text">
          </div>
          <div class="col-md-1">
          <label for="ex1"> DV</label>
          <input class="form-control" id="ss3" value="<?php echo $row_consultanom["dv"]; ?>" readonly type="text">
          </div>
			  </div>
			  <div class="form-group row">
			  <div class="col-md-2">
          <label for="ex2"> Telefono</label>
          <input class="form-control" id="ss9" value="<?php echo $row_consultanom["telefono"]; ?>" readonly type="text">
          </div>
		  <div class="col-md-7">
          <label for="ex1"> Direccion</label>
          <input class="form-control" id="ss11" value="<?php echo $row_consultanom["direccion"]; ?>" readonly type="text">
          </div>
		  <div class="col-md-1">
          <label for="ex1"> Corte</label>
          <input class="form-control" id="ss2" value="<?php echo $row_consultanom["dia_corte"]; ?>" readonly type="text">
          </div>          
		  </div>
		  <div class="form-group row">
			   <div class="col-md-2">
          <label for="ex1"> Sub Total</label>
          <input class="form-control" id="ss14" value="<?php echo number_format($subtotal); ?>" readonly type="text">
          </div>
          <div class="col-md-2">
          <input type="checkbox" value="s" id="coniva" name="coniva" checked><label for="ex1"> &nbsp;IVA</label>
          <input class="form-control" id="ss6" value="<?php echo number_format($iva); ?>" readonly type="text">
          </div>
			   <div class="col-md-2">
          <input type="checkbox" value="s" id="conretencion" name="conretencion" checked><label for="ex1">&nbsp;ReteFuente</label>
          <input class="form-control" id="ss16" value="<?php echo number_format($retefuente); ?>" readonly type="text">
          </div>
          <div class="col-md-2">
          <input type="checkbox" value="s" id="conreteica" name="conreteica" checked><label for="ex1"> ReteIca</label>
          <input class="form-control" id="ss17" value="<?php echo number_format($reteica); ?>" readonly type="text">
          </div>
			   <div class="col-md-2">
          <label for="ex1"> Total</label>
          <input class="form-control" id="ss18" value="<?php echo number_format($total); ?>" readonly type="text">
          </div>
          </div>
				</div>
		  <?php 
			  if ($subtotalc > 0) {?>	
			<hr align="left" noshade="noshade" size="4" width="80%" />
		  <div class="form-group row">
			  <div class="col-md-10">
          <label for="ex1">Descripci�n Compra:</label> 
          <textarea class="form-control" rows="5" id="editor" name="descripcionc" required></textarea>
          </div>
				</div>
         <div class="form-group row">
			  <div class="col-md-7">
          <label for="ex1"> Detalle Compra:</label>
          <input class="form-control" id="placasc" name="placasc" value="
              <?php
			  if($row_consultotalc["cantidad"]<8) {
				  echo "Placa: ";
              do {
				echo $row_consulplacasc["placa"]." "; 
			  } while ($row_consulplacasc = mysql_fetch_assoc($consulplacasc));
			  } else {
				  echo "VER ANEXO";
			  }?>" readonly type="text">	
          </div>
          <div class="col-md-2">
          <label for="ex1"> Valor Compra</label>
          <input class="form-control" id="valorc" name="vaolrc" value="<?php echo number_format($subtotalc); ?>" readonly type="text">
          </div>
         <div class="col-md-1">
          <label for="ex1"> Cantidad</label>
          <input class="form-control" id="cantidadc" name="cantidadc" value="<?php echo $row_consultotalc["cantidad"]; ?>" readonly type="text">
          </div>
				</div>
				<?php } ?>
			
		  <?php 
			  if ($subtotal1 > 0) {?>	
			<hr align="left" noshade="noshade" size="4" width="80%" />
		  <div class="form-group row">
			  <div class="col-md-10">
          <label for="ex1">Descripci�n Compra Prorateo:</label> 
          <textarea class="form-control" rows="5" id="editor1" name="descripcion1" required></textarea>
          <script type="text/javascript">
	CKEDITOR.replace( 'editor1' );
</script>
          </div>
				</div>
         <div class="form-group row">
			  <div class="col-md-7">
          <label for="ex1"> Detalle Compra Prorrateo:</label>
          <input class="form-control" id="placas1" name="placas1" value="
              <?php
			  if($row_consultotalcp["cantidad"]<8) {
				  echo "Placa: ";
              do {
				echo $row_consulplacascp1["placa"]." "; 
			  } while ($row_consulplacascp1 = mysql_fetch_assoc($consulplacascp1));
			  } else {
				  echo "VER ANEXO";
			  }?>" readonly type="text">	
          </div>
          <div class="col-md-2">
          <label for="ex1"> Valor Compra</label>
          <input class="form-control" id="valor1" name="valor1" value="<?php echo number_format($subtotal1); ?>" readonly type="text">
          </div>
         <div class="col-md-1">
          <label for="ex1"> Cantidad</label>
          <input class="form-control" id="cantidad1" name="cantidad1" value="<?php echo $row_consultotalcp["cantidad"]; ?>" readonly type="text">
          </div>
				</div>
				<?php } ?>
			
		  <?php 
			  if ($subtotala > 0) {?>	
			<hr align="left" noshade="noshade" size="4" width="80%" />		  
		  <div class="form-group row">
			  <div class="col-md-10">
          <label for="ex1">Descripci�n Arriendo: </label>".
          <textarea class="form-control" rows="5" id="editor3" name="descripciona" required></textarea>
          <script type="text/javascript">
	CKEDITOR.replace( 'editor3' );
</script>
          </div>
				</div>
				 <div class="form-group row">
			  <div class="col-md-7">
          <label for="ex1"> Detalle Arriendo:</label>
          <input class="form-control" id="placasa" name="placasa" value="
              <?php
			  if($row_consultotala["cantidad"]<8) {
				  echo "Placa: ";
              do {
				echo $row_consulplacasa["placa"]." "; 
			  } while ($row_consulplacasa = mysql_fetch_assoc($consulplacasa));
			  } else {
				  echo "VER ANEXO";
			  }?>" readonly type="text">	
          </div>
          <div class="col-md-2">
          <label for="ex1"> Valor Arriendo</label>
          <input class="form-control" id="valora" name="valora" value="<?php echo number_format($subtotala); ?>" readonly type="text">
          </div>
         <div class="col-md-1">
          <label for="ex1"> Cantidad</label>
          <input class="form-control" id="cantidada" name="cantidada" value="<?php echo $row_consultotala["cantidad"]; ?>" readonly type="text">
          </div>
				<?php } ?>
				
						  <?php 
			  if ($subtotal2 > 0) {?>	
			<hr align="left" noshade="noshade" size="4" width="80%" />
		  <div class="form-group row">
			  <div class="col-md-10">
          <label for="ex1">Descripci�n Arriendo Prorrateo:</label> 
          <textarea class="form-control" rows="5" id="editor4" name="descripcion2" required></textarea>
          <script type="text/javascript">
	CKEDITOR.replace( 'editor4' );
</script>
          </div>
				</div>
         <div class="form-group row">
			  <div class="col-md-7">
          <label for="ex1"> Detalle Arriendo Prorateo:</label>
          <input class="form-control" id="placas2" name="placas2" value="
              <?php
			  if($row_consultotalap["cantidad"]<8) {
				  echo "Placa: ";
              do {
				echo $row_consulplacasap["placa"]." "; 
			  } while ($row_consulplacasap = mysql_fetch_assoc($consulplacasap));
			  } else {
				  echo "VER ANEXO";
			  }?>" readonly type="text">	
          </div>
          <div class="col-md-2">
          <label for="ex1"> Valor Compra </label>
          <input class="form-control" id="valor2" name="valor2" value="<?php echo number_format($subtotal2); ?>" readonly type="text">
          </div>
         <div class="col-md-1">
          <label for="ex1"> Cantidad</label>
          <input class="form-control" id="cantidad2" name="cantidad2" value="<?php echo $row_consultotalap["cantidad"]; ?>" readonly type="text">
          </div>
				</div>
				<?php } ?>
				
				</div>
		  <div class="modal-footer">
			<button type="submit" class="btn btn-primary" id="actualizar_datos">GENERAR FACTURA</button>
			<a href="facturacion.php" class="btn btn-default" title='Cancelar' ><i class="glyphicon glyphicon-list-alt"> CANCELAR </i></a><br /><br />

		  </div>
		  </form>
		  </div>
		  </div>
		  </div>
		  </div>
		  </div>
		
		
		

<?php
	include("config/footer.php");
	?>
	<script>
	initSample();
</script>

</body>
</html>
<?php
mysql_free_result($consultanom);

mysql_free_result($consultotal);

mysql_free_result($consulplacas);

mysql_free_result($consultotala);

mysql_free_result($consulplacasa);

mysql_free_result($consultotalc);

mysql_free_result($consulplacasc);

mysql_free_result($consultotalcp);

mysql_free_result($consulplacascp);

mysql_free_result($consultotalap);

mysql_free_result($consulplacasap);
?>