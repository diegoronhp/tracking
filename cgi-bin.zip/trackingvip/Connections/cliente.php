<?php 
mysql_select_db($database_track, $track);
$query_cliente = "SELECT * FROM clientes ORDER BY nombre ASC";;
$cliente = mysql_query($query_cliente, $track) or die(mysql_error());
$row_cliente = mysql_fetch_assoc($cliente);
$totalRows_cliente = mysql_num_rows($cliente);

?>