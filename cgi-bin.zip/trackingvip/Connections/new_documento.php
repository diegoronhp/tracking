<?php
require_once('tracking.php'); 
require_once('../config/login.php');

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


mysql_select_db($database_track, $track);
$query_facturacion = "SELECT * FROM facturacion";;
$facturacion = mysql_query($query_facturacion, $track) or die(mysql_error());
$row_facturacion = mysql_fetch_assoc($facturacion);
$totalRows_facturacion = mysql_num_rows($facturacion);




if (empty($_POST['factura'])) {
           $errors[] = "Factura vac�o";
        }else if (empty($_POST['valor'])) {
           $errors[] = "Valor vac�o";
        }  else if ($_POST['fecha']==""){
			$errors[] = "Selecciona fecha";
		}  else if (
			!empty($_POST['factura']) &&
			!empty($_POST['valor'])
		){
		/* Connect To Database*/
		require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
		require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
		// escaping, additionally removing everything that could be (html/javascript-) code
	    $factura=mysqli_real_escape_string($con,(strip_tags($_POST["factura"],ENT_QUOTES)));
        $valor=mysqli_real_escape_string($con,(strip_tags($_POST["valor"],ENT_QUOTES)));
		$fecha=mysqli_real_escape_string($con,(strip_tags($_POST["fecha"],ENT_QUOTES)));
		$concepto=mysqli_real_escape_string($con,(strip_tags($_POST["concepto"],ENT_QUOTES)));
		$id_usuario=mysqli_real_escape_string($con,(strip_tags($_POST["id_usuario"],ENT_QUOTES)));
		$observaciones=mysqli_real_escape_string($con,(strip_tags($_POST["observaciones"],ENT_QUOTES)));

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

	
if (isset($_POST["factura"])) {
  $insertSQL = sprintf("INSERT INTO movfacturas (factura, concepto, valor, fecha, id_usuario, observaciones) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($factura, "text"),
					   GetSQLValueString($concepto, "text"),
                       GetSQLValueString($valor, "text"),
                       GetSQLValueString($fecha, "text"),
                       GetSQLValueString($id_usuario, "int"),
                       GetSQLValueString($observaciones, "text"));

  mysql_select_db($database_track, $track);
  $Result1 = mysql_query($insertSQL, $track) or die(mysql_error());
	
	
  $insertGoTo = "../consultafactura.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}	
}

mysql_free_result($usu);
mysql_free_result($facturacion);


?>
