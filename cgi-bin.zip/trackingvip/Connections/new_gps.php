<?php
require_once('tracking.php'); 
require_once('../config/login.php');
require_once('cliente.php');

$arnes = "SI";
mysql_select_db($database_track, $track);
$query_gps = "SELECT * FROM equipos";;
$gps = mysql_query($query_gps, $track) or die(mysql_error());
$row_gps = mysql_fetch_assoc($gps);
$totalRows_gps = mysql_num_rows($gps);

if (empty($_POST['imei'])) {
           $errors[] = "IMEI vac�o";
        }else if (empty($_POST['fecha'])) {
           $errors[] = "Fecha vac�o";
        }  else if (
			!empty($_POST['imei']) &&
			!empty($_POST['fecha']) &&
			$_POST['id_marca']!="" 
		){
		/* Connect To Database*/
		require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
		require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
		// escaping, additionally removing everything that could be (html/javascript-) code
	    $imei=mysqli_real_escape_string($con,(strip_tags($_POST["imei"],ENT_QUOTES)));
        $id_marca=mysqli_real_escape_string($con,(strip_tags($_POST["id_marca"],ENT_QUOTES)));
		$id_modelo=mysqli_real_escape_string($con,(strip_tags($_POST["id_modelo"],ENT_QUOTES)));
		$fecha=mysqli_real_escape_string($con,(strip_tags($_POST["fecha"],ENT_QUOTES)));
		$ubicacion=mysqli_real_escape_string($con,(strip_tags($_POST["ubicacion"],ENT_QUOTES)));
		$origen=mysqli_real_escape_string($con,(strip_tags($_POST["origen"],ENT_QUOTES)));
	    $arnes=mysqli_real_escape_string($con,(strip_tags($arnes,ENT_QUOTES)));



$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (isset($_POST['imei'])) {
  $insertSQL = sprintf("INSERT INTO equipos (id_marca, id_modelo, imei, arnes, fecha, ubicacion, origen) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($id_marca, "int"),
					   GetSQLValueString($id_modelo, "int"),
                       GetSQLValueString($imei, "text"),
                       GetSQLValueString($arnes, "text"),
                       GetSQLValueString($fecha, "text"),
                       GetSQLValueString($ubicacion, "text"),
                       GetSQLValueString($origen, "text"));

  mysql_select_db($database_track, $track);
  $Result1 = mysql_query($insertSQL, $track) or die(mysql_error());
	
  $insertGoTo = "../gps.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}	
}

mysql_free_result($usu);
mysql_free_result($gps);

?>
