<?php
$hostname_track = "localhost";
$database_track = "tucontac_tracking";
$username_track = "tucontac_track1";
$password_track = "tracking@1";
$track = mysql_pconnect($hostname_track, $username_track, $password_track) or trigger_error(mysql_error(),E_USER_ERROR); 
 


//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}

if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "u,a";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}



$colname_movil = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_usu = $_SESSION['MM_Username'];
}
mysql_select_db($database_track, $track);
$query_usu = sprintf("SELECT * FROM usuarios WHERE usuario = %s", GetSQLValueString($colname_usu, "text"));
$usu = mysql_query($query_usu, $track) or die(mysql_error());
$row_usu = mysql_fetch_assoc($usu);
$totalRows_usu = mysql_num_rows($usu);


mysql_select_db($database_track, $track);
$query_placas = "SELECT * FROM movequipos ORDER BY placa ASC";;
$placas = mysql_query($query_placas, $track) or die(mysql_error());
$row_placas = mysql_fetch_assoc($placas);
$totalRows_placas = mysql_num_rows($placas);

if (empty($_POST['tabla'])) {
           $errors[] = "Tabla vac�o";
		}  else if (
			!empty($_POST['tabla']) &&
			!empty($_POST['campo']) 
		){
		/* Connect To Database*/
		require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
		require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
		// escaping, additionally removing everything that could be (html/javascript-) code
	
$id_usuario = $row_usu["id_usuario"];
$placa = $_POST["placa"];	
$tabla = $_POST["tabla"];
$campo = $_POST["campo"];
$editar = $_POST[$campo];
	if ($_POST[$campo]=="a") {
$datocambio = "Activo";
	} else if ($_POST[$campo]=="i") {
$datocambio = "Inactivo";
	} else {
$datocambio = $_POST[$campo];		
	}
	if (isset($_POST["cambio"])) {
$cambio = $_POST["cambio"];
	} else {
$cambio = $datocambio;		
	}
		
	
	
        $aeditar=mysqli_real_escape_string($con,(strip_tags($editar,ENT_QUOTES)));

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (isset($_POST['tabla'])) {
		$placamov=mysqli_real_escape_string($con,(strip_tags($placa,ENT_QUOTES)));
		$campomov=mysqli_real_escape_string($con,(strip_tags($campo,ENT_QUOTES)));
		$cambiomov=mysqli_real_escape_string($con,(strip_tags($cambio,ENT_QUOTES)));
		$id_usuariomov=mysqli_real_escape_string($con,(strip_tags($id_usuario,ENT_QUOTES)));
											 
	$sqlnew="INSERT INTO cambiosmov (placa, campo, cambio, id_usuario) VALUES ('$placamov','$campomov','$cambiomov','$id_usuariomov')";
  mysql_select_db($database_track, $track);
  $Result2 = mysql_query($sqlnew, $track) or die(mysql_error());
	
  $updateSQL = sprintf("UPDATE $tabla SET $campo=%s WHERE placa='$placa'",
                       GetSQLValueString($aeditar, "text"));

   mysql_select_db($database_track, $track);
  $Result1 = mysql_query($updateSQL, $track) or die(mysql_error());

  $updateGoTo = "../edit_placa.php?placa=$placa";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}
}
echo "-".$id_usuario;
echo "-".$placa;
echo "-".$tabla;
echo "-".$campo;
echo "-".$editar;

mysql_free_result($usu);
mysql_free_result($placas);

?>
