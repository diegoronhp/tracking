<?php
require_once('tracking.php'); 
require_once('../config/login.php');

mysql_select_db($database_track, $track);
$query_linea = "SELECT * FROM sim ORDER BY linea ASC";
$linea = mysql_query($query_linea, $track) or die(mysql_error());
$row_linea = mysql_fetch_assoc($linea);
$totalRows_linea = mysql_num_rows($linea);

		/* Connect To Database*/
		require_once ("../config/db.php");//Contiene las variables de configuracion para conectar a la base de datos
		require_once ("../config/conexion.php");//Contiene funcion que conecta a la base de datos
		// escaping, additionally removing everything that could be (html/javascript-) code

if (empty($_POST['imei_sim'])) {
           $errors[] = "IMEI vac�o";
        }else if (empty($_POST['linea'])) {
           $errors[] = "Linea vac�a";
        }  else if ($_POST['estado']==""){
			$errors[] = "Selecciona el estado";
		}  else if (
			!empty($_POST['imei_sim']) &&
			!empty($_POST['linea']) &&
			$_POST['estado']!="" 
		){
	    $imei_sim=mysqli_real_escape_string($con,(strip_tags($_POST["imei_sim"],ENT_QUOTES)));
        $linea=mysqli_real_escape_string($con,(strip_tags($_POST["linea"],ENT_QUOTES)));
		$empresa_sim=mysqli_real_escape_string($con,(strip_tags($_POST["empresa_sim"],ENT_QUOTES)));
	    $estado=mysqli_real_escape_string($con,(strip_tags($_POST["estado"],ENT_QUOTES)));
	    $tipo=mysqli_real_escape_string($con,(strip_tags($_POST["tipo"],ENT_QUOTES)));



$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (isset($_POST['imei_sim'])) {
  $insertSQL = sprintf("INSERT INTO sim (imei_sim, linea, empresa_sim, estado, tipo) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($imei_sim, "text"),
                       GetSQLValueString($linea, "text"),
                       GetSQLValueString($empresa_sim, "text"),
                       GetSQLValueString($estado, "text"),
                       GetSQLValueString($tipo, "int"));

  mysql_select_db($database_track, $track);
  $Result1 = mysql_query($insertSQL, $track) or die(mysql_error());
	
  $insertGoTo = "../linea.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
	

	
	
}
	
if (isset($_POST['registro']) && $_POST['registro']==5) {
		$id_usuario=mysqli_real_escape_string($con,(strip_tags($_POST["id_usuario"],ENT_QUOTES)));
        $id_linea=mysqli_real_escape_string($con,(strip_tags($_POST["id_linea"],ENT_QUOTES)));
		$valor=mysqli_real_escape_string($con,(strip_tags($_POST["valor"],ENT_QUOTES)));
	    $fecha=mysqli_real_escape_string($con,(strip_tags($_POST["fecha"],ENT_QUOTES)));
  $insertSQL = sprintf("INSERT INTO recarga (id_usuario, id_linea, valor, fecha) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($id_usuario, "text"),
                       GetSQLValueString($id_linea, "text"),
                       GetSQLValueString($valor, "text"),
                       GetSQLValueString($fecha, "text"));

  mysql_select_db($database_track, $track);
  $Result1 = mysql_query($insertSQL, $track) or die(mysql_error());
	
  $insertGoTo = "../lineapre.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
mysql_free_result($usu);
mysql_free_result($linea);

?>
